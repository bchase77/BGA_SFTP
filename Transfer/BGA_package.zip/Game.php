<?php
/**
 *------
 * BGA framework: Gregory Isabelli & Emmanuel Colin & BoardGameArena
 * MatRevW implementation : © <Your name here> <Your email address here>
 *
 * This code has been produced on the BGA studio platform for use on http://boardgamearena.com.
 * See http://en.boardgamearena.com/#!doc/Studio for more information.
 * -----
 *
 * Game.php
 *
 * This is the main file for your game logic.
 *
 * In this PHP file, you are going to defines the rules of the game.
 */
declare(strict_types=1);

namespace Bga\Games\MatRevW;

require_once(APP_GAMEMODULE_PATH . "module/table/table.game.php");
require_once(__DIR__ . '/material.inc.php');

class Game extends \Table
{
    private static array $CARD_TYPES;
    private static array $OFFENSE_CARD_TYPES;
    private static array $DEFENSE_CARD_TYPES;
    private static array $TOP_CARD_TYPES;
    private static array $BOTTOM_CARD_TYPES;
    private static array $SCRAMBLE_CARD_TYPES;

    /**
     * Your global variables labels:
     *
     * Here, you can assign labels to global variables you are using for this game. You can use any number of global
     * variables with IDs between 10 and 99. If your game has options (variants), you also have to associate here a
     * label to the corresponding ID in `gameoptions.inc.php`.
     *
     * NOTE: afterward, you can get/set the global variables with `getGameStateValue`, `setGameStateInitialValue` or
     * `setGameStateValue` functions.
     */
    public function __construct()
    {
        parent::__construct();

        $this->initGameStateLabels([
            // "my_first_global_variable" => 10,
            // "my_second_global_variable" => 11,
            // "my_first_game_variant" => 100,
            // "my_second_game_variant" => 101,
			"period" => 10,
            "playerOnOffense" => 11,
            "playerOnDefense" => 12,
            "playerOnTop" => 13,
            "playerOnBottom" => 14,
            "playerOnOffenseCard" => 15,
            "playerOnDefenseCard" => 16,
            "playerOnTopCard" => 17,
            "playerOnBottomCard" => 18,
			"gameLengthOption" => 19
        ]);        

        self::$CARD_TYPES = [
            // 1 => [
                // "card_name" => clienttranslate('Troll'), // ...
            // ],
            // 2 => [
                // "card_name" => clienttranslate('Goblin'), // ...
            // ],
            // ...

			0 => [
				"card_name" => clienttranslate('None'), // ...
			],
			1 => [
				"card_name" => clienttranslate('Goldie Meadows'), // ...
			],
			2 => [
				"card_name" => clienttranslate('Frankie Boulay'), // ...
			],
        ];

        self::$OFFENSE_CARD_TYPES = [
			0 => [
				"card_name" => clienttranslate('Hand Fight'), // ...
			],
			1 => [
				"card_name" => clienttranslate('Fake Shot'), // ...
			],
        ];

        self::$DEFENSE_CARD_TYPES = [
			0 => [
				"card_name" => clienttranslate('Down Block'), // ...
			],
			1 => [
				"card_name" => clienttranslate('Sprawl'), // ...
			],
        ];

        self::$TOP_CARD_TYPES = [
			0 => [
				"card_name" => clienttranslate('Break Down'), // ...
			],
			1 => [
				"card_name" => clienttranslate('Mat Return'), // ...
			],
        ];
        
		self::$BOTTOM_CARD_TYPES = [
			0 => [
				"card_name" => clienttranslate('Hold Your Base'), // ...
			],
			1 => [
				"card_name" => clienttranslate('Base Up'), // ...
			],
        ];
		
        self::$SCRAMBLE_CARD_TYPES = [
			0 => [
				"card_name" => clienttranslate('One'), // ...
			],
			7 => [
				"card_name" => clienttranslate('Seven'), // ...
			],
			8 => [
				"card_name" => clienttranslate('Eight'), // ...
			],
        ];
        /* example of notification decorator.
        // automatically complete notification args when needed
        $this->notify->addDecorator(function(string $message, array $args) {
            if (isset($args['player_id']) && !isset($args['player_name']) && str_contains($message, '${player_name}')) {
                $args['player_name'] = $this->getPlayerNameById($args['player_id']);
            }
        
            if (isset($args['card_id']) && !isset($args['card_name']) && str_contains($message, '${card_name}')) {
                $args['card_name'] = self::$CARD_TYPES[$args['card_id']]['card_name'];
                $args['i18n'][] = ['card_name'];
            }
            
            return $args;
        });*/
    }

    /**
     * Player action, example content.
     *
     * In this scenario, each time a player plays a card, this method will be called. This method is called directly
     * by the action trigger on the front side with `bgaPerformAction`.
     *
     * @throws BgaUserException
     */
    public function actPlayCard(int $card_id): void
    {
        // Retrieve the active player ID.
        $player_id = (int)$this->getActivePlayerId();

        // check input values
        $args = $this->argPlayerTurn();
        $playableCardsIds = $args['playableCardsIds'];
        if (!in_array($card_id, $playableCardsIds)) {
            throw new \BgaUserException('Invalid card choice');
        }

        // Add your game logic to play a card here.
        $card_name = self::$CARD_TYPES[$card_id]['card_name'];

        // Notify all players about the card played.
        $this->notify->all("cardPlayed", clienttranslate('${player_name} plays ${card_name}'), [
            "player_id" => $player_id,
            "player_name" => $this->getActivePlayerName(), // remove this line if you uncomment notification decorator
            "card_name" => $card_name, // remove this line if you uncomment notification decorator
            "card_id" => $card_id,
            "i18n" => ['card_name'], // remove this line if you uncomment notification decorator
        ]);

        // at the end of the action, move to the next state
        $this->gamestate->nextState("playCard");
    }

    public function actPass(): void
    {
        // Retrieve the active player ID.
        $player_id = (int)$this->getActivePlayerId();

        // Notify all players about the choice to pass.
        $this->notify->all("pass", clienttranslate('${player_name} passes'), [
            "player_id" => $player_id,
            "player_name" => $this->getActivePlayerName(), // remove this line if you uncomment notification decorator
        ]);

        // at the end of the action, move to the next state
        $this->gamestate->nextState("pass");
    }

    /**
     * Game state arguments, example content.
     *
     * This method returns some additional information that is very specific to the `playerTurn` game state.
     *
     * @return array
     * @see ./states.inc.php
     */
    public function argPlayerTurn(): array
    {
        // Get some values from the current game situation from the database.

        return [
            "playableCardsIds" => [1, 2],
        ];
    }

    /**
     * Compute and return the current game progression.
     *
     * The number returned must be an integer between 0 and 100.
     *
     * This method is called each time we are in a game state with the "updateGameProgression" property set to true.
     *
     * @return int
     * @see ./states.inc.php
     */
    public function getGameProgression()
    {
        // TODO: compute and return the game progression

        return 0;
    }

    /**
     * Game state action, example content.
     *
     * The action method of state `nextPlayer` is called everytime the current game state is set to `nextPlayer`.
     */
    public function stNextPlayer(): void
	{
        // Retrieve the active player ID.
        $player_id = (int)$this->getActivePlayerId();

        // Give some extra time to the active player when he completed an action
        $this->giveExtraTime($player_id);
        
        $this->activeNextPlayer();

        // Go to another gamestate
        // Here, we would detect if the game is over, and in this case use "endGame" transition instead 
        $this->gamestate->nextState("nextPlayer");
    }

    /**
     * Migrate database.
     *
     * You don't have to care about this until your game has been published on BGA. Once your game is on BGA, this
     * method is called everytime the system detects a game running with your old database scheme. In this case, if you
     * change your database scheme, you just have to apply the needed changes in order to update the game database and
     * allow the game to continue to run with your new version.
     *
     * @param int $from_version
     * @return void
     */
    public function upgradeTableDb($from_version)
    {
//       if ($from_version <= 1404301345)
//       {
//            // ! important ! Use DBPREFIX_<table_name> for all tables
//
//            $sql = "ALTER TABLE DBPREFIX_xxxxxxx ....";
//            $this->applyDbUpgradeToAllDB( $sql );
//       }
//
//       if ($from_version <= 1405061421)
//       {
//            // ! important ! Use DBPREFIX_<table_name> for all tables
//
//            $sql = "CREATE TABLE DBPREFIX_xxxxxxx ....";
//            $this->applyDbUpgradeToAllDB( $sql );
//       }
    }

    /*
     * Gather all information about current game situation (visible by the current player).
     *
     * The method is called each time the game interface is displayed to a player, i.e.:
     *
     * - when the game starts
     * - when a player refreshes the game page (F5)
     */
    protected function getAllDatas(): array
    {
        $result = [];

        // WARNING: We must only return information visible by the current player.
        $current_player_id = (int) $this->getCurrentPlayerId();

		// Let the clients know game state so they know to have them choose wrestler or other actions
		$state = $this->gamestate->state();

		$result[ 'state' ] = $state;
/*
		$result[ 'periods' ] = $this->periods;
		$result[ 'period1Rounds' ] = $this->period1Rounds;
		$result[ 'period2Rounds' ] = $this->period2Rounds;
		$result[ 'period3Rounds' ] = $this->period3Rounds;
*/
        // Get information about players.
        // NOTE: you can retrieve some extra field you added for "player" table in `dbmodel.sql` if you need it.
        $result[ "players" ] = $this->getCollectionFromDb(
            "SELECT `player_id` `id`, `player_score` `score` FROM `player`"
        );

		$player_id = self::getCurrentPlayerId();
		$result['wrestlerCards'] = $this->wrestlerCards;














        // TODO: Gather all information about current game situation (visible by player $current_player_id).

		$this->playerOnOffense = self::getGameStateValue( 'playerOnOffense' );
		$this->playerOnDefense = self::getGameStateValue( 'playerOnDefense' );
		$this->playerOnTop     = self::getGameStateValue( 'playerOnTop' );
		$this->playerOnBottom  = self::getGameStateValue( 'playerOnBottom' );
		
		$result[ 'playerOnOffense' ] = $this->playerOnOffense;
		$result[ 'playerOnDefense' ] = $this->playerOnDefense;
		$result[ 'playerOnTop' ]     = $this->playerOnTop;
		$result[ 'playerOnBottom' ]  = $this->playerOnBottom;
		$result[ 'playerOnOffenseCard' ] = $this->wrestlerCards[ self::getGameStateValue( 'playerOnOffenseCard' )];
		$result[ 'playerOnDefenseCard' ] = $this->wrestlerCards[ self::getGameStateValue( 'playerOnDefenseCard' )];
		$result[ 'playerOnTopCard' ]     = $this->wrestlerCards[ self::getGameStateValue( 'playerOnTopCard' )];
		$result[ 'playerOnBottomCard' ]  = $this->wrestlerCards[ self::getGameStateValue( 'playerOnBottomCard' )];

		// Add the fields with statistics to each back deck to send to the JS clients
		
		//
		// Deck of Offense cards
		//
/*
		$deckO = $this->cards->getCardsInLocation( 'deckOffense' );
		self::dump( "[bmc] OffenseCards: ", $deckO );
		
//		$fullDeck = [];
		$fullDeck = (array) null;
		
		foreach( $deckO as $card ) {
			// self::dump( "[bmc] card: ", $card );
			$searchKey = array('Name' => $card['type']);
			// self::dump( "[bmc] searchKey: ", $searchKey );

			$searchResult = self::searchForCard( $this->offenseCards, $searchKey );
			// self::dump( "[bmc] searchResult: ", $searchResult );

			$fullDeck[] = array_merge( $card, $searchResult );
		}
		
		// self::dump( "[bmc] fullDeck: ", $fullDeck );
		$result[ 'deckOffense' ]   = $fullDeck;

		//
		// Deck of Defense cards
		//
		
		$deckO = $this->cards->getCardsInLocation( 'deckDefense' );
		self::dump( "[bmc] DefenseCards: ", $deckO );
		
		$fullDeck = (array) null;
		
		foreach( $deckO as $card ) {
			// self::dump( "[bmc] card: ", $card );
			$searchKey = array('Name' => $card['type']);
			// self::dump( "[bmc] searchKey: ", $searchKey );

			$searchResult = self::searchForCard( $this->defenseCards, $searchKey );
			// self::dump( "[bmc] searchResult: ", $searchResult );

			$fullDeck[] = array_merge( $card, $searchResult );
		}
		
		// self::dump( "[bmc] fullDeck: ", $fullDeck );
		$result[ 'deckDefense' ]   = $fullDeck;

		//
		// Deck of Top cards
		//
		
		$deckO = $this->cards->getCardsInLocation( 'deckTop' );
		self::dump( "[bmc] TopCards: ", $deckO );
		
		$fullDeck = (array) null;
		
		foreach( $deckO as $card ) {
			// self::dump( "[bmc] card: ", $card );
			$searchKey = array('Name' => $card['type']);
			// self::dump( "[bmc] searchKey: ", $searchKey );

			$searchResult = self::searchForCard( $this->topCards, $searchKey );
			// self::dump( "[bmc] searchResult: ", $searchResult );

			$fullDeck[] = array_merge( $card, $searchResult );
		}
		
		// self::dump( "[bmc] fullDeck: ", $fullDeck );
		$result[ 'deckTop' ]   = $fullDeck;

		//
		// Deck of Bottom cards
		//
		
		$deckO = $this->cards->getCardsInLocation( 'deckBottom' );
		self::dump( "[bmc] BottomCards: ", $deckO );
		
		$fullDeck = (array) null;
		
		foreach( $deckO as $card ) {
			// self::dump( "[bmc] card: ", $card );
			$searchKey = array('Name' => $card['type']);
			// self::dump( "[bmc] searchKey: ", $searchKey );

			$searchResult = self::searchForCard( $this->bottomCards, $searchKey );
			// self::dump( "[bmc] searchResult: ", $searchResult );

			$fullDeck[] = array_merge( $card, $searchResult );
		}
		
		// self::dump( "[bmc] fullDeck: ", $fullDeck );
		$result[ 'deckBottom' ]   = $fullDeck;

		//
		// Deck of Wrester cards
		//
		
		$deckO = $this->cards->getCardsInLocation( 'deckWrestler' );
		self::dump( "[bmc] WrestlerCards: ", $deckO );
		
		$fullDeck = (array) null;
		
		foreach( $deckO as $card ) {
			// self::dump( "[bmc] card: ", $card );
			$searchKey = array('Name' => $card['type']);
			// self::dump( "[bmc] searchKey: ", $searchKey );

			$searchResult = self::searchForCard( $this->wrestlerCards, $searchKey );
			// self::dump( "[bmc] searchResult: ", $searchResult );

			$fullDeck[] = array_merge( $card, $searchResult );
		}
		
		// self::dump( "[bmc] fullDeck: ", $fullDeck );
		$result[ 'deckWrestler' ]   = $fullDeck;

		//
		// Deck of Scramble cards
		//
		
		$deckO = $this->cards->getCardsInLocation( 'deckScramble' );
		self::dump( "[bmc] ScrambleCards: ", $deckO );
		
		$fullDeck = (array) null;
		
		foreach( $deckO as $card ) {
			// self::dump( "[bmc] card: ", $card );
			$searchKey = array('Name' => $card['type']);
			// self::dump( "[bmc] searchKey: ", $searchKey );

			$searchResult = self::searchForCard( $this->scrambleCards, $searchKey );
			// self::dump( "[bmc] searchResult: ", $searchResult );

			$fullDeck[] = array_merge( $card, $searchResult );
		}
		
		// self::dump( "[bmc] fullDeck: ", $fullDeck );
		$result[ 'deckScramble' ]   = $fullDeck;
*/
        return $result;
    }

/*	function stDeckSetup()
	{
		// Traces from this function won't appear in the BGA Request&SQL Logs output
		self::trace("[bmc] Enter setupNewDeck");
		
		// The BGA element 'deck' won't store anything beyond id, type, type_arg, location and location_arg in the database.
		// So, will create a deck for each Offense, Defense, Top, Bottom and Wrestler cards and make parallel data
		// structures to store the other parameters, like conditioning modifiers.
		
		//
		// Create Offense Card Deck
		//
		$deck = (array) null;
		
		foreach( $this->offenseCards as $CO ) {
			$deck[] = array( 'type' => $CO['Name'], 'type_arg' => 'type_arg', 'nbr' => 1 );
		}

        $this->cards->createCards( $deck, $location='deckOffense' );

		//
		// Create Defense Card Deck
		//
		$deck = (array) null;

		foreach( $this->defenseCards as $CO ) {
			$deck[] = array( 'type' => $CO['Name'], 'type_arg' => 'type_arg', 'nbr' => 1 );
		}

        $this->cards->createCards( $deck, $location='deckDefense' );

		//
		// Create Top Card Deck
		//
		$deck = (array) null;
		
		foreach( $this->topCards as $CO ) {
			$deck[] = array( 'type' => $CO['Name'], 'type_arg' => 'type_arg', 'nbr' => 1 );
		}

        $this->cards->createCards( $deck, $location='deckTop' );

		//
		// Create Bottom Card Deck
		//
		$deck = (array) null;
		
		foreach( $this->bottomCards as $CO ) {
			$deck[] = array( 'type' => $CO['Name'], 'type_arg' => 'type_arg', 'nbr' => 1 );
		}

        $this->cards->createCards( $deck, $location='deckBottom' );

		//
		// Create Scramble Card Deck
		//
		$deck = (array) null;
		
		foreach( $this->scrambleCards as $CO ) {
			$deck[] = array( 'type' => $CO['Name'], 'type_arg' => 'type_arg', 'nbr' => 1 );
		}

        $this->cards->createCards( $deck, $location='deckScramble' );

		//
		// Create Wrestler Card Deck
		//
		$deck = (array) null;
		
		foreach( $this->wrestlerCards as $CO ) {
			$deck[] = array( 'type' => $CO['Name'], 'type_arg' => 'type_arg', 'nbr' => 1 );
		}

        $this->cards->createCards( $deck, $location='deckWrestler' );

		// Go to the next game state
        $this->gamestate->nextState();	

		self::trace("[bmc] Exit setupNewDeck");
	}
*/
    /**
     * Returns the game name.
     *
     * IMPORTANT: Please do not modify.
     */
    protected function getGameName()
    {
        return "matrevw";
    }

    /**
     * This method is called only once, when a new game is launched. In this method, you must setup the game
     *  according to the game rules, so that the game is ready to be played.
     */
    protected function setupNewGame($players, $options = [])
    {
        // Set the colors of the players with HTML color code. The default below is red/green/blue/orange/brown. The
        // number of colors defined here must correspond to the maximum number of players allowed for the gams.
        $gameinfos = $this->getGameinfos();
        $default_colors = $gameinfos['player_colors'];

        foreach ($players as $player_id => $player) {
            // Now you can access both $player_id and $player array
            $query_values[] = vsprintf("('%s', '%s', '%s', '%s', '%s')", [
                $player_id,
                array_shift($default_colors),
                $player["player_canal"],
                addslashes($player["player_name"]),
                addslashes($player["player_avatar"]),
            ]);
        }

        // Create players based on generic information.
        //
        // NOTE: You can add extra field on player table in the database (see dbmodel.sql) and initialize
        // additional fields directly here.
        static::DbQuery(
            sprintf(
                "INSERT INTO player (player_id, player_color, player_canal, player_name, player_avatar) VALUES %s",
                implode(",", $query_values)
            )
        );

        $this->reattributeColorsBasedOnPreferences($players, $gameinfos["player_colors"]);
        $this->reloadPlayersBasicInfos();

        // Init global values with their initial values.

        $this->setGameStateInitialValue("period", 1 );

        // Activate first player once everything has been initialized and ready.
        $this->setGameStateInitialValue('wrestlerSelectionDone', 0);
		$this->gamestate->nextState('next');  // leads into ST_PLAYER_CHOOSE_WRESTLER
		$this->activeNextPlayer();

        // Init game statistics.
        //
        // NOTE: statistics used in this file must be defined in your `stats.inc.php` file.

        // Dummy content.
        // $this->initStat("table", "table_teststat1", 0);
        // $this->initStat("player", "player_teststat1", 0);

        // TODO: Setup the initial game situation here.

		// Initial values are 0. Player with higher conditioning will choose Off or Def; Coin flip if tied.
		
		// self::setGameStateInitialValue( 'playerOnOffense', 0 );
		// self::setGameStateInitialValue( 'playerOnDefense', 0 );
		// self::setGameStateInitialValue( 'playerOnTop', 0 );
		// self::setGameStateInitialValue( 'playerOnBottom', 0 );
    }


	function actChooseWrestler($wrestlerId)
	{
		self::checkAction('chooseWrestler');

		$playerId = self::getActivePlayerId();

		$card = $this->wrestlerCards[$wrestlerId] ?? null;
		if ($card === null) {
			throw new BgaUserException("Invalid wrestler ID");
		}

		// Check if already chosen
		$taken = self::getUniqueValueFromDB("SELECT COUNT(*) FROM player WHERE wrestler = '" . self::escapeStringForDB($card['name']) . "'");
		if ($taken > 0) {
			throw new BgaUserException("That wrestler is already taken");
		}

		// Save to player DB row
		self::DbQuery("UPDATE player SET wrestler = '" . self::escapeStringForDB($card['name']) . "' WHERE player_id = $playerId");

		// Notify player(s)
		self::notifyAllPlayers('wrestlerChosen', clienttranslate('${player_name} chose ${wrestler}'), [
			'player_id' => $playerId,
			'player_name' => self::getActivePlayerName(),
			'wrestler' => $card['name'],
		]);

		$this->gamestate->nextState('next');
	}


	function setGameLength()
	{
//		$gameLengthOption = $this->getGameStateValue( 'gameLengthOption' );

		$thisTableLength = $this->getGameStateValue( 'gameLengthOption' );
	
		if ( $thisTableLength == 1 ) {
			$this->periods = 3;
			$this->period1Rounds = 9;
			$this->period2Rounds = 6;
			$this->period3Rounds = 6;
		} else {
			$this->periods = 3;
			$this->period1Rounds = 6;
			$this->period2Rounds = 3;
			$this->period3Rounds = 3;
		}
	}

    /**
     * This method is called each time it is the turn of a player who has quit the game (= "zombie" player).
     * You can do whatever you want in order to make sure the turn of this player ends appropriately
     * (ex: pass).
     *
     * Important: your zombie code will be called when the player leaves the game. This action is triggered
     * from the main site and propagated to the gameserver from a server, not from a browser.
     * As a consequence, there is no current player associated to this action. In your zombieTurn function,
     * you must _never_ use `getCurrentPlayerId()` or `getCurrentPlayerName()`, otherwise it will fail with a
     * "Not logged" error message.
     *
     * @param array{ type: string, name: string } $state
     * @param int $active_player
     * @return void
     * @throws feException if the zombie mode is not supported at this game state.
     */
    protected function zombieTurn(array $state, int $active_player): void
    {
        $state_name = $state["name"];

        if ($state["type"] === "activeplayer") {
            switch ($state_name) {
                default:
                {
                    $this->gamestate->nextState("zombiePass");
                    break;
                }
            }

            return;
        }

        // Make sure player is in a non-blocking status for role turn.
        if ($state["type"] === "multipleactiveplayer") {
            $this->gamestate->setPlayerNonMultiactive($active_player, '');
            return;
        }

        throw new \feException("Zombie mode not supported at this game state: \"{$state_name}\".");
    }
}
